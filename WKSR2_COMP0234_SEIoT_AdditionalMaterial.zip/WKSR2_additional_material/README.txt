COMP0234 SEIoT MSc Final Project Report 2026 - Candidate WKSR2
Additional material

WKSR2_COMP0234_SEIoT_Demo.mp4  (2 min 59 s, 1280x720, narrated)

  0:00  Introduction: the question the dissertation asks.
  0:26  One live closed-loop run: the fine-tuned Qwen3-0.6B student (int4, Microsoft
        Foundry Local, one 6 GB consumer GPU) controlling the nine signalised junctions
        of the demand-calibrated Bloomsbury grid (686 vehicles, 1,200 s, seed 1).
        Left: SUMO vehicle positions; junction rings show who authored the last served
        phase (model, shield, anti-starvation floor). Right: live feed of signed
        decision records with per-call latency and the advancing chain hash.
  1:14  Run summary from SUMO tripinfo: 598/686 completed, 0 teleports, 435 decisions,
        model-authored 335 (0.77), divergence from MaxPressure 0.04, chain verified.
        One seed is a demonstration; the report's results use 30 paired seeds.
  1:34  Audit chain: verify_chain and verify_signatures pass; a tampered phase breaks
        the chain; a forged signature keeps the chain but fails verification.
  1:56  Crash reconstruction suite: seven scenarios, chain + signatures + forgery caught
        + governing UK rule inferred from verified facts.
  2:13  The ambulance evidence pack: cited rules with the knowledge base's weights, no verdict.
  2:31  Headline results and stated limits, as in the report.

Everything in the video was computed in the run shown; nothing is mocked.
The narration is synthesised speech reading a fixed script.
The report itself is uploaded separately as the project report PDF.
